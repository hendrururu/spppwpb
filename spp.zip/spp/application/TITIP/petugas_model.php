<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Petugas_model extends CI_Model
{
    private $_table = "petugas";

    public $id_petugas;
    public $nama_petugas;
    public $image = "default.jpg";

    public function rules()
    {
        return [

            ['field' => 'nama_petugas',
            'label' => 'Nama Petugas',
            'rules' => 'required'],
            
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id_petugas)
    {
        return $this->db->get_where($this->_table, ["id_petugas" => $id_petugas])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->nama_petugas = $post["nama_petugas"];
        $this->image = $this->_uploadImage();
        $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id_petugas = $post["id"];
        $this->nama_petugas = $post["nama_petugas"];
        if (!empty($_FILES["image"]["name"])) {
            $this->image = $this->_uploadImage();
        } else {
            $this->image = $post["old_image"];
        }
        $this->db->update($this->_table, $this, array('id_petugas' => $post['id']));
    }

    public function delete($id)
    {   
        $this->_deleteImage($id);
        return $this->db->delete($this->_table, array("id_petugas" => $id));
    }

    private function _uploadImage()
    {
        $config['upload_path']          = './upload/petugas/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['file_name']            = $this->id_petugas;
        $config['overwrite']            = true;
        $config['max_size']             = 1024; // 1MB
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('image')) {
            return $this->upload->data("file_name");
        }
        
        return "default.jpg";
    }

    private function _deleteImage($id)
    {
        $petugas = $this->getById($id);
        if ($petugas->image != "default.jpg") {
            $filename = explode(".", $petugas->image)[0];
            return array_map('unlink', glob(FCPATH."upload/petugas/$filename.*"));
        }
    }

}
